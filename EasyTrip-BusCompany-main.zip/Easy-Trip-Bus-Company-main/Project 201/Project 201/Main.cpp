#include "Company.h"
#include "Station.h"
#include <iostream>

int main() {
	Company app;
	app.Simulate();
}